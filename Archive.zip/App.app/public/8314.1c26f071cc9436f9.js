'use strict';
(self.webpackChunkapp = self.webpackChunkapp || []).push([
  [8314],
  {
    8314: (S, m, l) => {
      l.r(m), l.d(m, { ion_breadcrumb: () => I, ion_breadcrumbs: () => M });
      var o = l(4261),
        C = l(4920),
        c = l(333),
        u = l(3992),
        f = l(9483);
      const I = (() => {
          let d = class {
            constructor(s) {
              (0, o.r)(this, s),
                (this.ionFocus = (0, o.d)(this, 'ionFocus', 7)),
                (this.ionBlur = (0, o.d)(this, 'ionBlur', 7)),
                (this.collapsedClick = (0, o.d)(this, 'collapsedClick', 7)),
                (this.inheritedAttributes = {}),
                (this.onFocus = () => {
                  this.ionFocus.emit();
                }),
                (this.onBlur = () => {
                  this.ionBlur.emit();
                }),
                (this.collapsedIndicatorClick = () => {
                  this.collapsedClick.emit({
                    ionShadowTarget: this.collapsedRef,
                  });
                }),
                (this.collapsed = !1),
                (this.last = void 0),
                (this.showCollapsedIndicator = void 0),
                (this.color = void 0),
                (this.active = !1),
                (this.disabled = !1),
                (this.download = void 0),
                (this.href = void 0),
                (this.rel = void 0),
                (this.separator = void 0),
                (this.target = void 0),
                (this.routerDirection = 'forward'),
                (this.routerAnimation = void 0);
            }
            componentWillLoad() {
              this.inheritedAttributes = (0, C.i)(this.el);
            }
            isClickable() {
              return void 0 !== this.href;
            }
            render() {
              const {
                  color: s,
                  active: i,
                  collapsed: r,
                  disabled: t,
                  download: a,
                  el: b,
                  inheritedAttributes: e,
                  last: n,
                  routerAnimation: p,
                  routerDirection: z,
                  separator: E,
                  showCollapsedIndicator: g,
                  target: O,
                } = this,
                x = this.isClickable(),
                v = void 0 === this.href ? 'span' : 'a',
                k = t ? void 0 : this.href,
                y = (0, f.b)(this),
                D = 'span' === v ? {} : { download: a, href: k, target: O },
                j = !n && (r ? !(!g || n) : E);
              return (0, o.h)(
                o.f,
                {
                  key: 'dfe55ad57f23e5da5f2e2c51fea99964812472e3',
                  onClick: (h) => (0, c.o)(k, h, z, p),
                  'aria-disabled': t ? 'true' : null,
                  class: (0, c.c)(s, {
                    [y]: !0,
                    'breadcrumb-active': i,
                    'breadcrumb-collapsed': r,
                    'breadcrumb-disabled': t,
                    'in-breadcrumbs-color': (0, c.h)(
                      'ion-breadcrumbs[color]',
                      b,
                    ),
                    'in-toolbar': (0, c.h)('ion-toolbar', this.el),
                    'in-toolbar-color': (0, c.h)('ion-toolbar[color]', this.el),
                    'ion-activatable': x,
                    'ion-focusable': x,
                  }),
                },
                (0, o.h)(
                  v,
                  Object.assign(
                    { key: 'e361b1f0e7de6dd5c5dd4f6deae72c2c8210466d' },
                    D,
                    {
                      class: 'breadcrumb-native',
                      part: 'native',
                      disabled: t,
                      onFocus: this.onFocus,
                      onBlur: this.onBlur,
                    },
                    e,
                  ),
                  (0, o.h)('slot', {
                    key: '9daeb45a8a28c89f3ad5751f71b8412197846371',
                    name: 'start',
                  }),
                  (0, o.h)('slot', {
                    key: '4849e63cdffd6c712292745138b68730442c8b0d',
                  }),
                  (0, o.h)('slot', {
                    key: '6edf9bac5aec06ccec2844efac2d9afa1d24cf57',
                    name: 'end',
                  }),
                ),
                g &&
                  (0, o.h)(
                    'button',
                    {
                      key: 'de7f5faea75b44011b289d259265e2435a65874f',
                      part: 'collapsed-indicator',
                      'aria-label': 'Show more breadcrumbs',
                      onClick: () => this.collapsedIndicatorClick(),
                      ref: (h) => (this.collapsedRef = h),
                      class: { 'breadcrumbs-collapsed-indicator': !0 },
                    },
                    (0, o.h)('ion-icon', {
                      key: '957d8851af9c99dda263f34eff0b35a0fc212c32',
                      'aria-hidden': 'true',
                      icon: u.n,
                      lazy: !1,
                    }),
                  ),
                j &&
                  (0, o.h)(
                    'span',
                    {
                      key: '97d646c37c4c41ad6b12c3a543d1146fde06fc9a',
                      class: 'breadcrumb-separator',
                      part: 'separator',
                      'aria-hidden': 'true',
                    },
                    (0, o.h)(
                      'slot',
                      {
                        key: '0429f671a986f2d7be1b1b69fc879e80806d2916',
                        name: 'separator',
                      },
                      'ios' === y
                        ? (0, o.h)('ion-icon', {
                            icon: u.m,
                            lazy: !1,
                            'flip-rtl': !0,
                          })
                        : (0, o.h)('span', null, '/'),
                    ),
                  ),
              );
            }
            get el() {
              return (0, o.i)(this);
            }
          };
          return (
            (d.style = {
              ios: ':host{display:-ms-flexbox;display:flex;-ms-flex:0 0 auto;flex:0 0 auto;-ms-flex-align:center;align-items:center;color:var(--color);font-size:1rem;font-weight:400;line-height:1.5}.breadcrumb-native{font-family:inherit;font-size:inherit;font-style:inherit;font-weight:inherit;letter-spacing:inherit;text-decoration:inherit;text-indent:inherit;text-overflow:inherit;text-transform:inherit;text-align:inherit;white-space:inherit;color:inherit;padding-left:0;padding-right:0;padding-top:0;padding-bottom:0;margin-left:0;margin-right:0;margin-top:0;margin-bottom:0;display:-ms-flexbox;display:flex;-ms-flex-align:center;align-items:center;width:100%;outline:none;background:inherit}:host(.breadcrumb-disabled){cursor:default;opacity:0.5;pointer-events:none}:host(.breadcrumb-active){color:var(--color-active)}:host(.ion-focused){color:var(--color-focused)}:host(.ion-focused) .breadcrumb-native{background:var(--background-focused)}@media (any-hover: hover){:host(.ion-activatable:hover){color:var(--color-hover)}:host(.ion-activatable.in-breadcrumbs-color:hover),:host(.ion-activatable.ion-color:hover){color:var(--ion-color-shade)}}.breadcrumb-separator{display:-ms-inline-flexbox;display:inline-flex}:host(.breadcrumb-collapsed) .breadcrumb-native{display:none}:host(.in-breadcrumbs-color),:host(.in-breadcrumbs-color.breadcrumb-active){color:var(--ion-color-base)}:host(.in-breadcrumbs-color) .breadcrumb-separator{color:var(--ion-color-base)}:host(.ion-color){color:var(--ion-color-base)}:host(.in-toolbar-color),:host(.in-toolbar-color) .breadcrumb-separator{color:rgba(var(--ion-color-contrast-rgb), 0.8)}:host(.in-toolbar-color.breadcrumb-active){color:var(--ion-color-contrast)}.breadcrumbs-collapsed-indicator{padding-left:0;padding-right:0;padding-top:0;padding-bottom:0;-webkit-margin-start:14px;margin-inline-start:14px;-webkit-margin-end:14px;margin-inline-end:14px;margin-top:0;margin-bottom:0;display:-ms-flexbox;display:flex;-ms-flex:1 1 100%;flex:1 1 100%;-ms-flex-align:center;align-items:center;-ms-flex-pack:center;justify-content:center;width:32px;height:18px;border:0;outline:none;cursor:pointer;-webkit-appearance:none;-moz-appearance:none;appearance:none}.breadcrumbs-collapsed-indicator ion-icon{margin-top:1px;font-size:1.375rem}:host{--color:var(--ion-color-step-850, var(--ion-text-color-step-150, #2d4665));--color-active:var(--ion-text-color, #03060b);--color-hover:var(--ion-text-color, #03060b);--color-focused:var(--color-active);--background-focused:var(--ion-color-step-50, var(--ion-background-color-step-50, rgba(233, 237, 243, 0.7)));font-size:clamp(16px, 1rem, 22px)}:host(.breadcrumb-active){font-weight:600}.breadcrumb-native{border-radius:4px;-webkit-padding-start:12px;padding-inline-start:12px;-webkit-padding-end:12px;padding-inline-end:12px;padding-top:5px;padding-bottom:5px;border:1px solid transparent}:host(.ion-focused) .breadcrumb-native{border-radius:8px}:host(.in-breadcrumbs-color.ion-focused) .breadcrumb-native,:host(.ion-color.ion-focused) .breadcrumb-native{background:rgba(var(--ion-color-base-rgb), 0.1);color:var(--ion-color-base)}:host(.ion-focused) ::slotted(ion-icon),:host(.in-breadcrumbs-color.ion-focused) ::slotted(ion-icon),:host(.ion-color.ion-focused) ::slotted(ion-icon){color:var(--ion-color-step-750, var(--ion-text-color-step-250, #445b78))}.breadcrumb-separator{color:var(--ion-color-step-550, var(--ion-text-color-step-450, #73849a))}::slotted(ion-icon){color:var(--ion-color-step-400, var(--ion-text-color-step-600, #92a0b3));font-size:min(1.125rem, 21.6px)}::slotted(ion-icon[slot=start]){-webkit-margin-end:8px;margin-inline-end:8px}::slotted(ion-icon[slot=end]){-webkit-margin-start:8px;margin-inline-start:8px}:host(.breadcrumb-active) ::slotted(ion-icon){color:var(--ion-color-step-850, var(--ion-text-color-step-150, #242d39))}.breadcrumbs-collapsed-indicator{border-radius:4px;background:var(--ion-color-step-100, var(--ion-background-color-step-100, #e9edf3));color:var(--ion-color-step-550, var(--ion-text-color-step-450, #73849a))}.breadcrumbs-collapsed-indicator:hover{opacity:0.45}.breadcrumbs-collapsed-indicator:focus{background:var(--ion-color-step-150, var(--ion-background-color-step-150, #d9e0ea))}.breadcrumbs-collapsed-indicator ion-icon{font-size:min(1.375rem, 22px)}',
              md: ':host{display:-ms-flexbox;display:flex;-ms-flex:0 0 auto;flex:0 0 auto;-ms-flex-align:center;align-items:center;color:var(--color);font-size:1rem;font-weight:400;line-height:1.5}.breadcrumb-native{font-family:inherit;font-size:inherit;font-style:inherit;font-weight:inherit;letter-spacing:inherit;text-decoration:inherit;text-indent:inherit;text-overflow:inherit;text-transform:inherit;text-align:inherit;white-space:inherit;color:inherit;padding-left:0;padding-right:0;padding-top:0;padding-bottom:0;margin-left:0;margin-right:0;margin-top:0;margin-bottom:0;display:-ms-flexbox;display:flex;-ms-flex-align:center;align-items:center;width:100%;outline:none;background:inherit}:host(.breadcrumb-disabled){cursor:default;opacity:0.5;pointer-events:none}:host(.breadcrumb-active){color:var(--color-active)}:host(.ion-focused){color:var(--color-focused)}:host(.ion-focused) .breadcrumb-native{background:var(--background-focused)}@media (any-hover: hover){:host(.ion-activatable:hover){color:var(--color-hover)}:host(.ion-activatable.in-breadcrumbs-color:hover),:host(.ion-activatable.ion-color:hover){color:var(--ion-color-shade)}}.breadcrumb-separator{display:-ms-inline-flexbox;display:inline-flex}:host(.breadcrumb-collapsed) .breadcrumb-native{display:none}:host(.in-breadcrumbs-color),:host(.in-breadcrumbs-color.breadcrumb-active){color:var(--ion-color-base)}:host(.in-breadcrumbs-color) .breadcrumb-separator{color:var(--ion-color-base)}:host(.ion-color){color:var(--ion-color-base)}:host(.in-toolbar-color),:host(.in-toolbar-color) .breadcrumb-separator{color:rgba(var(--ion-color-contrast-rgb), 0.8)}:host(.in-toolbar-color.breadcrumb-active){color:var(--ion-color-contrast)}.breadcrumbs-collapsed-indicator{padding-left:0;padding-right:0;padding-top:0;padding-bottom:0;-webkit-margin-start:14px;margin-inline-start:14px;-webkit-margin-end:14px;margin-inline-end:14px;margin-top:0;margin-bottom:0;display:-ms-flexbox;display:flex;-ms-flex:1 1 100%;flex:1 1 100%;-ms-flex-align:center;align-items:center;-ms-flex-pack:center;justify-content:center;width:32px;height:18px;border:0;outline:none;cursor:pointer;-webkit-appearance:none;-moz-appearance:none;appearance:none}.breadcrumbs-collapsed-indicator ion-icon{margin-top:1px;font-size:1.375rem}:host{--color:var(--ion-color-step-600, var(--ion-text-color-step-400, #677483));--color-active:var(--ion-text-color, #03060b);--color-hover:var(--ion-text-color, #03060b);--color-focused:var(--ion-color-step-800, var(--ion-text-color-step-200, #35404e));--background-focused:var(--ion-color-step-50, var(--ion-background-color-step-50, #fff))}:host(.breadcrumb-active){font-weight:500}.breadcrumb-native{-webkit-padding-start:12px;padding-inline-start:12px;-webkit-padding-end:12px;padding-inline-end:12px;padding-top:6px;padding-bottom:6px}.breadcrumb-separator{-webkit-margin-start:10px;margin-inline-start:10px;-webkit-margin-end:10px;margin-inline-end:10px;margin-top:-1px}:host(.ion-focused) .breadcrumb-native{border-radius:4px;-webkit-box-shadow:0px 1px 2px rgba(0, 0, 0, 0.2), 0px 2px 8px rgba(0, 0, 0, 0.12);box-shadow:0px 1px 2px rgba(0, 0, 0, 0.2), 0px 2px 8px rgba(0, 0, 0, 0.12)}.breadcrumb-separator{color:var(--ion-color-step-550, var(--ion-text-color-step-450, #73849a))}::slotted(ion-icon){color:var(--ion-color-step-550, var(--ion-text-color-step-450, #7d8894));font-size:1.125rem}::slotted(ion-icon[slot=start]){-webkit-margin-end:8px;margin-inline-end:8px}::slotted(ion-icon[slot=end]){-webkit-margin-start:8px;margin-inline-start:8px}:host(.breadcrumb-active) ::slotted(ion-icon){color:var(--ion-color-step-850, var(--ion-text-color-step-150, #222d3a))}.breadcrumbs-collapsed-indicator{border-radius:2px;background:var(--ion-color-step-100, var(--ion-background-color-step-100, #eef1f3));color:var(--ion-color-step-550, var(--ion-text-color-step-450, #73849a))}.breadcrumbs-collapsed-indicator:hover{opacity:0.7}.breadcrumbs-collapsed-indicator:focus{background:var(--ion-color-step-150, var(--ion-background-color-step-150, #dfe5e8))}',
            }),
            d
          );
        })(),
        M = (() => {
          let d = class {
            constructor(s) {
              (0, o.r)(this, s),
                (this.ionCollapsedClick = (0, o.d)(
                  this,
                  'ionCollapsedClick',
                  7,
                )),
                (this.breadcrumbsInit = () => {
                  this.setBreadcrumbSeparator(), this.setMaxItems();
                }),
                (this.resetActiveBreadcrumb = () => {
                  const r = this.getBreadcrumbs().find((t) => t.active);
                  r && this.activeChanged && (r.active = !1);
                }),
                (this.setMaxItems = () => {
                  const {
                      itemsAfterCollapse: i,
                      itemsBeforeCollapse: r,
                      maxItems: t,
                    } = this,
                    a = this.getBreadcrumbs();
                  for (const e of a)
                    (e.showCollapsedIndicator = !1), (e.collapsed = !1);
                  void 0 !== t &&
                    a.length > t &&
                    r + i <= t &&
                    a.forEach((e, n) => {
                      n === r && (e.showCollapsedIndicator = !0),
                        n >= r && n < a.length - i && (e.collapsed = !0);
                    });
                }),
                (this.setBreadcrumbSeparator = () => {
                  const {
                      itemsAfterCollapse: i,
                      itemsBeforeCollapse: r,
                      maxItems: t,
                    } = this,
                    a = this.getBreadcrumbs(),
                    b = a.find((e) => e.active);
                  for (const e of a) {
                    const n =
                      void 0 !== t && 0 === i
                        ? e === a[r]
                        : e === a[a.length - 1];
                    (e.last = n),
                      (e.separator =
                        void 0 !== e.separator ? e.separator : !n || void 0),
                      !b && n && ((e.active = !0), (this.activeChanged = !0));
                  }
                }),
                (this.getBreadcrumbs = () =>
                  Array.from(this.el.querySelectorAll('ion-breadcrumb'))),
                (this.slotChanged = () => {
                  this.resetActiveBreadcrumb(), this.breadcrumbsInit();
                }),
                (this.collapsed = void 0),
                (this.activeChanged = void 0),
                (this.color = void 0),
                (this.maxItems = void 0),
                (this.itemsBeforeCollapse = 1),
                (this.itemsAfterCollapse = 1);
            }
            onCollapsedClick(s) {
              const r = this.getBreadcrumbs().filter((t) => t.collapsed);
              this.ionCollapsedClick.emit(
                Object.assign(Object.assign({}, s.detail), {
                  collapsedBreadcrumbs: r,
                }),
              );
            }
            maxItemsChanged() {
              this.resetActiveBreadcrumb(), this.breadcrumbsInit();
            }
            componentWillLoad() {
              this.breadcrumbsInit();
            }
            render() {
              const { color: s, collapsed: i } = this,
                r = (0, f.b)(this);
              return (0, o.h)(
                o.f,
                {
                  key: '18ffba1642f10cc2bc31440e84f23aa6f042e501',
                  class: (0, c.c)(s, {
                    [r]: !0,
                    'in-toolbar': (0, c.h)('ion-toolbar', this.el),
                    'in-toolbar-color': (0, c.h)('ion-toolbar[color]', this.el),
                    'breadcrumbs-collapsed': i,
                  }),
                },
                (0, o.h)('slot', {
                  key: '3db6d31590e3047889ce554d57d155c8ea2e1455',
                  onSlotchange: this.slotChanged,
                }),
              );
            }
            get el() {
              return (0, o.i)(this);
            }
            static get watchers() {
              return {
                maxItems: ['maxItemsChanged'],
                itemsBeforeCollapse: ['maxItemsChanged'],
                itemsAfterCollapse: ['maxItemsChanged'],
              };
            }
          };
          return (
            (d.style = {
              ios: ':host{-moz-osx-font-smoothing:grayscale;-webkit-font-smoothing:antialiased;display:-ms-flexbox;display:flex;-ms-flex-wrap:wrap;flex-wrap:wrap;-ms-flex-align:center;align-items:center}:host(.in-toolbar-color),:host(.in-toolbar-color) .breadcrumbs-collapsed-indicator ion-icon{color:var(--ion-color-contrast)}:host(.in-toolbar-color) .breadcrumbs-collapsed-indicator{background:rgba(var(--ion-color-contrast-rgb), 0.11)}:host(.in-toolbar){-webkit-padding-start:20px;padding-inline-start:20px;-webkit-padding-end:20px;padding-inline-end:20px;padding-top:0;padding-bottom:0;-ms-flex-pack:center;justify-content:center}',
              md: ':host{-moz-osx-font-smoothing:grayscale;-webkit-font-smoothing:antialiased;display:-ms-flexbox;display:flex;-ms-flex-wrap:wrap;flex-wrap:wrap;-ms-flex-align:center;align-items:center}:host(.in-toolbar-color),:host(.in-toolbar-color) .breadcrumbs-collapsed-indicator ion-icon{color:var(--ion-color-contrast)}:host(.in-toolbar-color) .breadcrumbs-collapsed-indicator{background:rgba(var(--ion-color-contrast-rgb), 0.11)}:host(.in-toolbar){-webkit-padding-start:8px;padding-inline-start:8px;-webkit-padding-end:8px;padding-inline-end:8px;padding-top:0;padding-bottom:0}',
            }),
            d
          );
        })();
    },
  },
]);
