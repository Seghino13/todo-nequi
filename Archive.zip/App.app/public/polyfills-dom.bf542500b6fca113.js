(self.webpackChunkapp = self.webpackChunkapp || []).push([
  [7278],
  {
    2190: () => {
      var f, h, s;
      (function () {
        'use strict';
        var f = new Set(
          'annotation-xml color-profile font-face font-face-src font-face-uri font-face-format font-face-name missing-glyph'.split(
            ' ',
          ),
        );
        function h(e) {
          var t = f.has(e);
          return (e = /^[a-z][.0-9_a-z]*-[\-.0-9_a-z]*$/.test(e)), !t && e;
        }
        function s(e) {
          var t = e.isConnected;
          if (void 0 !== t) return t;
          for (; e && !(e.__CE_isImportDocument || e instanceof Document); )
            e =
              e.parentNode ||
              (window.ShadowRoot && e instanceof ShadowRoot ? e.host : void 0);
          return !(!e || !(e.__CE_isImportDocument || e instanceof Document));
        }
        function m(e, t) {
          for (; t && t !== e && !t.nextSibling; ) t = t.parentNode;
          return t && t !== e ? t.nextSibling : null;
        }
        function p(e, t, n) {
          n = void 0 === n ? new Set() : n;
          for (var r = e; r; ) {
            if (r.nodeType === Node.ELEMENT_NODE) {
              var o = r;
              t(o);
              var i = o.localName;
              if ('link' === i && 'import' === o.getAttribute('rel')) {
                if ((r = o.import) instanceof Node && !n.has(r))
                  for (n.add(r), r = r.firstChild; r; r = r.nextSibling)
                    p(r, t, n);
                r = m(e, o);
                continue;
              }
              if ('template' === i) {
                r = m(e, o);
                continue;
              }
              if ((o = o.__CE_shadowRoot))
                for (o = o.firstChild; o; o = o.nextSibling) p(o, t, n);
            }
            r = r.firstChild ? r.firstChild : m(e, r);
          }
        }
        function d(e, t, n) {
          e[t] = n;
        }
        function C() {
          (this.a = new Map()),
            (this.g = new Map()),
            (this.c = []),
            (this.f = []),
            (this.b = !1);
        }
        function O(e, t) {
          e.b &&
            p(t, function (n) {
              return _(e, n);
            });
        }
        function _(e, t) {
          if (e.b && !t.__CE_patched) {
            t.__CE_patched = !0;
            for (var n = 0; n < e.c.length; n++) e.c[n](t);
            for (n = 0; n < e.f.length; n++) e.f[n](t);
          }
        }
        function w(e, t) {
          var n = [];
          for (
            p(t, function (o) {
              return n.push(o);
            }),
              t = 0;
            t < n.length;
            t++
          ) {
            var r = n[t];
            1 === r.__CE_state ? e.connectedCallback(r) : S(e, r);
          }
        }
        function v(e, t) {
          var n = [];
          for (
            p(t, function (o) {
              return n.push(o);
            }),
              t = 0;
            t < n.length;
            t++
          ) {
            var r = n[t];
            1 === r.__CE_state && e.disconnectedCallback(r);
          }
        }
        function E(e, t, n) {
          var r = (n = void 0 === n ? {} : n).u || new Set(),
            o =
              n.i ||
              function (l) {
                return S(e, l);
              },
            i = [];
          if (
            (p(
              t,
              function (l) {
                if (
                  'link' === l.localName &&
                  'import' === l.getAttribute('rel')
                ) {
                  var c = l.import;
                  c instanceof Node &&
                    ((c.__CE_isImportDocument = !0), (c.__CE_hasRegistry = !0)),
                    c && 'complete' === c.readyState
                      ? (c.__CE_documentLoadHandled = !0)
                      : l.addEventListener('load', function () {
                          var a = l.import;
                          if (!a.__CE_documentLoadHandled) {
                            a.__CE_documentLoadHandled = !0;
                            var u = new Set(r);
                            u.delete(a), E(e, a, { u, i: o });
                          }
                        });
                } else i.push(l);
              },
              r,
            ),
            e.b)
          )
            for (t = 0; t < i.length; t++) _(e, i[t]);
          for (t = 0; t < i.length; t++) o(i[t]);
        }
        function S(e, t) {
          if (void 0 === t.__CE_state) {
            var n = t.ownerDocument;
            if (
              (n.defaultView ||
                (n.__CE_isImportDocument && n.__CE_hasRegistry)) &&
              (n = e.a.get(t.localName))
            ) {
              n.constructionStack.push(t);
              var r = n.constructorFunction;
              try {
                try {
                  if (new r() !== t)
                    throw Error(
                      'The custom element constructor did not produce the element being upgraded.',
                    );
                } finally {
                  n.constructionStack.pop();
                }
              } catch (l) {
                throw ((t.__CE_state = 2), l);
              }
              if (
                ((t.__CE_state = 1),
                (t.__CE_definition = n),
                n.attributeChangedCallback)
              )
                for (n = n.observedAttributes, r = 0; r < n.length; r++) {
                  var o = n[r],
                    i = t.getAttribute(o);
                  null !== i && e.attributeChangedCallback(t, o, null, i, null);
                }
              s(t) && e.connectedCallback(t);
            }
          }
        }
        function P(e) {
          var t = document;
          (this.c = e),
            (this.a = t),
            (this.b = void 0),
            E(this.c, this.a),
            'loading' === this.a.readyState &&
              ((this.b = new MutationObserver(this.f.bind(this))),
              this.b.observe(this.a, { childList: !0, subtree: !0 }));
        }
        function F(e) {
          e.b && e.b.disconnect();
        }
        function lt() {
          var e = this;
          (this.b = this.a = void 0),
            (this.c = new Promise(function (t) {
              (e.b = t), e.a && t(e.a);
            }));
        }
        function I(e) {
          if (e.a) throw Error('Already resolved.');
          (e.a = void 0), e.b && e.b(void 0);
        }
        function y(e) {
          (this.c = !1),
            (this.a = e),
            (this.j = new Map()),
            (this.f = function (t) {
              return t();
            }),
            (this.b = !1),
            (this.g = []),
            (this.o = new P(e));
        }
        (C.prototype.connectedCallback = function (e) {
          var t = e.__CE_definition;
          t.connectedCallback && t.connectedCallback.call(e);
        }),
          (C.prototype.disconnectedCallback = function (e) {
            var t = e.__CE_definition;
            t.disconnectedCallback && t.disconnectedCallback.call(e);
          }),
          (C.prototype.attributeChangedCallback = function (e, t, n, r, o) {
            var i = e.__CE_definition;
            i.attributeChangedCallback &&
              -1 < i.observedAttributes.indexOf(t) &&
              i.attributeChangedCallback.call(e, t, n, r, o);
          }),
          (P.prototype.f = function (e) {
            var t = this.a.readyState;
            for (
              ('interactive' !== t && 'complete' !== t) || F(this), t = 0;
              t < e.length;
              t++
            )
              for (var n = e[t].addedNodes, r = 0; r < n.length; r++)
                E(this.c, n[r]);
          }),
          (y.prototype.l = function (e, t) {
            var n = this;
            if (!(t instanceof Function))
              throw new TypeError(
                'Custom element constructors must be functions.',
              );
            if (!h(e))
              throw new SyntaxError(
                "The element name '" + e + "' is not valid.",
              );
            if (this.a.a.get(e))
              throw Error(
                "A custom element with name '" +
                  e +
                  "' has already been defined.",
              );
            if (this.c)
              throw Error('A custom element is already being defined.');
            this.c = !0;
            try {
              var r = function (g) {
                  var N = o[g];
                  if (void 0 !== N && !(N instanceof Function))
                    throw Error("The '" + g + "' callback must be a function.");
                  return N;
                },
                o = t.prototype;
              if (!(o instanceof Object))
                throw new TypeError(
                  "The custom element constructor's prototype is not an object.",
                );
              var i = r('connectedCallback'),
                l = r('disconnectedCallback'),
                c = r('adoptedCallback'),
                a = r('attributeChangedCallback'),
                u = t.observedAttributes || [];
            } catch {
              return;
            } finally {
              this.c = !1;
            }
            (function ot(e, t, n) {
              e.a.set(t, n), e.g.set(n.constructorFunction, n);
            })(
              this.a,
              e,
              (t = {
                localName: e,
                constructorFunction: t,
                connectedCallback: i,
                disconnectedCallback: l,
                adoptedCallback: c,
                attributeChangedCallback: a,
                observedAttributes: u,
                constructionStack: [],
              }),
            ),
              this.g.push(t),
              this.b ||
                ((this.b = !0),
                this.f(function () {
                  return (function st(e) {
                    if (!1 !== e.b) {
                      e.b = !1;
                      for (
                        var t = e.g, n = [], r = new Map(), o = 0;
                        o < t.length;
                        o++
                      )
                        r.set(t[o].localName, []);
                      for (
                        E(e.a, document, {
                          i: function (c) {
                            if (void 0 === c.__CE_state) {
                              var a = c.localName,
                                u = r.get(a);
                              u ? u.push(c) : e.a.a.get(a) && n.push(c);
                            }
                          },
                        }),
                          o = 0;
                        o < n.length;
                        o++
                      )
                        S(e.a, n[o]);
                      for (; 0 < t.length; ) {
                        var i = t.shift();
                        (o = i.localName), (i = r.get(i.localName));
                        for (var l = 0; l < i.length; l++) S(e.a, i[l]);
                        (o = e.j.get(o)) && I(o);
                      }
                    }
                  })(n);
                }));
          }),
          (y.prototype.i = function (e) {
            E(this.a, e);
          }),
          (y.prototype.get = function (e) {
            if ((e = this.a.a.get(e))) return e.constructorFunction;
          }),
          (y.prototype.m = function (e) {
            if (!h(e))
              return Promise.reject(
                new SyntaxError(
                  "'" + e + "' is not a valid custom element name.",
                ),
              );
            var t = this.j.get(e);
            return (
              t ||
                ((t = new lt()),
                this.j.set(e, t),
                this.a.a.get(e) &&
                  !this.g.some(function (n) {
                    return n.localName === e;
                  }) &&
                  I(t)),
              t.c
            );
          }),
          (y.prototype.s = function (e) {
            F(this.o);
            var t = this.f;
            this.f = function (n) {
              return e(function () {
                return t(n);
              });
            };
          }),
          (window.CustomElementRegistry = y),
          (y.prototype.define = y.prototype.l),
          (y.prototype.upgrade = y.prototype.i),
          (y.prototype.get = y.prototype.get),
          (y.prototype.whenDefined = y.prototype.m),
          (y.prototype.polyfillWrapFlushCallback = y.prototype.s);
        var z = window.Document.prototype.createElement,
          U = window.Document.prototype.createElementNS,
          ct = window.Document.prototype.importNode,
          at = window.Document.prototype.prepend,
          ut = window.Document.prototype.append,
          pt = window.DocumentFragment.prototype.prepend,
          ft = window.DocumentFragment.prototype.append,
          B = window.Node.prototype.cloneNode,
          T = window.Node.prototype.appendChild,
          W = window.Node.prototype.insertBefore,
          j = window.Node.prototype.removeChild,
          V = window.Node.prototype.replaceChild,
          k = Object.getOwnPropertyDescriptor(
            window.Node.prototype,
            'textContent',
          ),
          $ = window.Element.prototype.attachShadow,
          L = Object.getOwnPropertyDescriptor(
            window.Element.prototype,
            'innerHTML',
          ),
          M = window.Element.prototype.getAttribute,
          G = window.Element.prototype.setAttribute,
          J = window.Element.prototype.removeAttribute,
          D = window.Element.prototype.getAttributeNS,
          K = window.Element.prototype.setAttributeNS,
          Q = window.Element.prototype.removeAttributeNS,
          Y = window.Element.prototype.insertAdjacentElement,
          Z = window.Element.prototype.insertAdjacentHTML,
          ht = window.Element.prototype.prepend,
          dt = window.Element.prototype.append,
          x = window.Element.prototype.before,
          mt = window.Element.prototype.after,
          X = window.Element.prototype.replaceWith,
          q = window.Element.prototype.remove,
          gt = window.HTMLElement,
          H = Object.getOwnPropertyDescriptor(
            window.HTMLElement.prototype,
            'innerHTML',
          ),
          tt = window.HTMLElement.prototype.insertAdjacentElement,
          et = window.HTMLElement.prototype.insertAdjacentHTML,
          nt = new (function () {})();
        function R(e, t, n) {
          function r(o) {
            return function (i) {
              for (var l = [], c = 0; c < arguments.length; ++c)
                l[c] = arguments[c];
              c = [];
              for (var a = [], u = 0; u < l.length; u++) {
                var g = l[u];
                if (
                  (g instanceof Element && s(g) && a.push(g),
                  g instanceof DocumentFragment)
                )
                  for (g = g.firstChild; g; g = g.nextSibling) c.push(g);
                else c.push(g);
              }
              for (o.apply(this, l), l = 0; l < a.length; l++) v(e, a[l]);
              if (s(this))
                for (l = 0; l < c.length; l++)
                  (a = c[l]) instanceof Element && w(e, a);
            };
          }
          void 0 !== n.h && (t.prepend = r(n.h)),
            void 0 !== n.append && (t.append = r(n.append));
        }
        var A = window.customElements;
        if (
          !A ||
          A.forcePolyfill ||
          'function' != typeof A.define ||
          'function' != typeof A.get
        ) {
          var b = new C();
          (function yt() {
            var e = b;
            window.HTMLElement = (function () {
              function t() {
                var n = this.constructor,
                  r = e.g.get(n);
                if (!r)
                  throw Error(
                    'The custom element being constructed was not registered with `customElements`.',
                  );
                var o = r.constructionStack;
                if (0 === o.length)
                  return (
                    (o = z.call(document, r.localName)),
                    Object.setPrototypeOf(o, n.prototype),
                    (o.__CE_state = 1),
                    (o.__CE_definition = r),
                    _(e, o),
                    o
                  );
                var i = o[(r = o.length - 1)];
                if (i === nt)
                  throw Error(
                    'The HTMLElement constructor was either called reentrantly for this constructor or called multiple times.',
                  );
                return (
                  (o[r] = nt), Object.setPrototypeOf(i, n.prototype), _(e, i), i
                );
              }
              return (
                (t.prototype = gt.prototype),
                Object.defineProperty(t.prototype, 'constructor', {
                  writable: !0,
                  configurable: !0,
                  enumerable: !1,
                  value: t,
                }),
                t
              );
            })();
          })(),
            (function vt() {
              var e = b;
              d(Document.prototype, 'createElement', function (t) {
                if (this.__CE_hasRegistry) {
                  var n = e.a.get(t);
                  if (n) return new n.constructorFunction();
                }
                return (t = z.call(this, t)), _(e, t), t;
              }),
                d(Document.prototype, 'importNode', function (t, n) {
                  return (
                    (t = ct.call(this, t, !!n)),
                    this.__CE_hasRegistry ? E(e, t) : O(e, t),
                    t
                  );
                }),
                d(Document.prototype, 'createElementNS', function (t, n) {
                  if (
                    this.__CE_hasRegistry &&
                    (null === t || 'http://www.w3.org/1999/xhtml' === t)
                  ) {
                    var r = e.a.get(n);
                    if (r) return new r.constructorFunction();
                  }
                  return (t = U.call(this, t, n)), _(e, t), t;
                }),
                R(e, Document.prototype, { h: at, append: ut });
            })(),
            R(b, DocumentFragment.prototype, { h: pt, append: ft }),
            (function wt() {
              function e(n, r) {
                Object.defineProperty(n, 'textContent', {
                  enumerable: r.enumerable,
                  configurable: !0,
                  get: r.get,
                  set: function (o) {
                    if (this.nodeType === Node.TEXT_NODE) r.set.call(this, o);
                    else {
                      var i = void 0;
                      if (this.firstChild) {
                        var l = this.childNodes,
                          c = l.length;
                        if (0 < c && s(this)) {
                          i = Array(c);
                          for (var a = 0; a < c; a++) i[a] = l[a];
                        }
                      }
                      if ((r.set.call(this, o), i))
                        for (o = 0; o < i.length; o++) v(t, i[o]);
                    }
                  },
                });
              }
              var t = b;
              d(Node.prototype, 'insertBefore', function (n, r) {
                if (n instanceof DocumentFragment) {
                  var o = Array.prototype.slice.apply(n.childNodes);
                  if (((n = W.call(this, n, r)), s(this)))
                    for (r = 0; r < o.length; r++) w(t, o[r]);
                  return n;
                }
                return (
                  (o = s(n)),
                  (r = W.call(this, n, r)),
                  o && v(t, n),
                  s(this) && w(t, n),
                  r
                );
              }),
                d(Node.prototype, 'appendChild', function (n) {
                  if (n instanceof DocumentFragment) {
                    var r = Array.prototype.slice.apply(n.childNodes);
                    if (((n = T.call(this, n)), s(this)))
                      for (var o = 0; o < r.length; o++) w(t, r[o]);
                    return n;
                  }
                  return (
                    (r = s(n)),
                    (o = T.call(this, n)),
                    r && v(t, n),
                    s(this) && w(t, n),
                    o
                  );
                }),
                d(Node.prototype, 'cloneNode', function (n) {
                  return (
                    (n = B.call(this, !!n)),
                    this.ownerDocument.__CE_hasRegistry ? E(t, n) : O(t, n),
                    n
                  );
                }),
                d(Node.prototype, 'removeChild', function (n) {
                  var r = s(n),
                    o = j.call(this, n);
                  return r && v(t, n), o;
                }),
                d(Node.prototype, 'replaceChild', function (n, r) {
                  if (n instanceof DocumentFragment) {
                    var o = Array.prototype.slice.apply(n.childNodes);
                    if (((n = V.call(this, n, r)), s(this)))
                      for (v(t, r), r = 0; r < o.length; r++) w(t, o[r]);
                    return n;
                  }
                  o = s(n);
                  var i = V.call(this, n, r),
                    l = s(this);
                  return l && v(t, r), o && v(t, n), l && w(t, n), i;
                }),
                k && k.get
                  ? e(Node.prototype, k)
                  : (function rt(e, t) {
                      (e.b = !0), e.c.push(t);
                    })(t, function (n) {
                      e(n, {
                        enumerable: !0,
                        configurable: !0,
                        get: function () {
                          for (
                            var r = [], o = 0;
                            o < this.childNodes.length;
                            o++
                          ) {
                            var i = this.childNodes[o];
                            i.nodeType !== Node.COMMENT_NODE &&
                              r.push(i.textContent);
                          }
                          return r.join('');
                        },
                        set: function (r) {
                          for (; this.firstChild; )
                            j.call(this, this.firstChild);
                          null != r &&
                            '' !== r &&
                            T.call(this, document.createTextNode(r));
                        },
                      });
                    });
            })(),
            (function Ct() {
              function e(o, i) {
                Object.defineProperty(o, 'innerHTML', {
                  enumerable: i.enumerable,
                  configurable: !0,
                  get: i.get,
                  set: function (l) {
                    var c = this,
                      a = void 0;
                    if (
                      (s(this) &&
                        ((a = []),
                        p(this, function (N) {
                          N !== c && a.push(N);
                        })),
                      i.set.call(this, l),
                      a)
                    )
                      for (var u = 0; u < a.length; u++) {
                        var g = a[u];
                        1 === g.__CE_state && r.disconnectedCallback(g);
                      }
                    return (
                      this.ownerDocument.__CE_hasRegistry
                        ? E(r, this)
                        : O(r, this),
                      l
                    );
                  },
                });
              }
              function t(o, i) {
                d(o, 'insertAdjacentElement', function (l, c) {
                  var a = s(c);
                  return (
                    (l = i.call(this, l, c)), a && v(r, c), s(l) && w(r, c), l
                  );
                });
              }
              function n(o, i) {
                function l(c, a) {
                  for (var u = []; c !== a; c = c.nextSibling) u.push(c);
                  for (a = 0; a < u.length; a++) E(r, u[a]);
                }
                d(o, 'insertAdjacentHTML', function (c, a) {
                  if ('beforebegin' === (c = c.toLowerCase())) {
                    var u = this.previousSibling;
                    i.call(this, c, a),
                      l(u || this.parentNode.firstChild, this);
                  } else if ('afterbegin' === c)
                    (u = this.firstChild),
                      i.call(this, c, a),
                      l(this.firstChild, u);
                  else if ('beforeend' === c)
                    (u = this.lastChild),
                      i.call(this, c, a),
                      l(u || this.firstChild, null);
                  else {
                    if ('afterend' !== c)
                      throw new SyntaxError(
                        'The value provided (' +
                          String(c) +
                          ") is not one of 'beforebegin', 'afterbegin', 'beforeend', or 'afterend'.",
                      );
                    (u = this.nextSibling),
                      i.call(this, c, a),
                      l(this.nextSibling, u);
                  }
                });
              }
              var r = b;
              $ &&
                d(Element.prototype, 'attachShadow', function (o) {
                  o = $.call(this, o);
                  var i = r;
                  if (i.b && !o.__CE_patched) {
                    o.__CE_patched = !0;
                    for (var l = 0; l < i.c.length; l++) i.c[l](o);
                  }
                  return (this.__CE_shadowRoot = o);
                }),
                L && L.get
                  ? e(Element.prototype, L)
                  : H && H.get
                    ? e(HTMLElement.prototype, H)
                    : (function it(e, t) {
                        (e.b = !0), e.f.push(t);
                      })(r, function (o) {
                        e(o, {
                          enumerable: !0,
                          configurable: !0,
                          get: function () {
                            return B.call(this, !0).innerHTML;
                          },
                          set: function (i) {
                            var l = 'template' === this.localName,
                              c = l ? this.content : this,
                              a = U.call(
                                document,
                                this.namespaceURI,
                                this.localName,
                              );
                            for (a.innerHTML = i; 0 < c.childNodes.length; )
                              j.call(c, c.childNodes[0]);
                            for (
                              i = l ? a.content : a;
                              0 < i.childNodes.length;

                            )
                              T.call(c, i.childNodes[0]);
                          },
                        });
                      }),
                d(Element.prototype, 'setAttribute', function (o, i) {
                  if (1 !== this.__CE_state) return G.call(this, o, i);
                  var l = M.call(this, o);
                  G.call(this, o, i),
                    (i = M.call(this, o)),
                    r.attributeChangedCallback(this, o, l, i, null);
                }),
                d(Element.prototype, 'setAttributeNS', function (o, i, l) {
                  if (1 !== this.__CE_state) return K.call(this, o, i, l);
                  var c = D.call(this, o, i);
                  K.call(this, o, i, l),
                    (l = D.call(this, o, i)),
                    r.attributeChangedCallback(this, i, c, l, o);
                }),
                d(Element.prototype, 'removeAttribute', function (o) {
                  if (1 !== this.__CE_state) return J.call(this, o);
                  var i = M.call(this, o);
                  J.call(this, o),
                    null !== i &&
                      r.attributeChangedCallback(this, o, i, null, null);
                }),
                d(Element.prototype, 'removeAttributeNS', function (o, i) {
                  if (1 !== this.__CE_state) return Q.call(this, o, i);
                  var l = D.call(this, o, i);
                  Q.call(this, o, i);
                  var c = D.call(this, o, i);
                  l !== c && r.attributeChangedCallback(this, i, l, c, o);
                }),
                tt
                  ? t(HTMLElement.prototype, tt)
                  : Y
                    ? t(Element.prototype, Y)
                    : console.warn(
                        'Custom Elements: `Element#insertAdjacentElement` was not patched.',
                      ),
                et
                  ? n(HTMLElement.prototype, et)
                  : Z
                    ? n(Element.prototype, Z)
                    : console.warn(
                        'Custom Elements: `Element#insertAdjacentHTML` was not patched.',
                      ),
                R(r, Element.prototype, { h: ht, append: dt }),
                (function Et(e) {
                  function t(r) {
                    return function (o) {
                      for (var i = [], l = 0; l < arguments.length; ++l)
                        i[l] = arguments[l];
                      l = [];
                      for (var c = [], a = 0; a < i.length; a++) {
                        var u = i[a];
                        if (
                          (u instanceof Element && s(u) && c.push(u),
                          u instanceof DocumentFragment)
                        )
                          for (u = u.firstChild; u; u = u.nextSibling)
                            l.push(u);
                        else l.push(u);
                      }
                      for (r.apply(this, i), i = 0; i < c.length; i++)
                        v(e, c[i]);
                      if (s(this))
                        for (i = 0; i < l.length; i++)
                          (c = l[i]) instanceof Element && w(e, c);
                    };
                  }
                  var n = Element.prototype;
                  void 0 !== x && (n.before = t(x)),
                    void 0 !== x && (n.after = t(mt)),
                    void 0 !== X &&
                      d(n, 'replaceWith', function (r) {
                        for (var o = [], i = 0; i < arguments.length; ++i)
                          o[i] = arguments[i];
                        i = [];
                        for (var l = [], c = 0; c < o.length; c++) {
                          var a = o[c];
                          if (
                            (a instanceof Element && s(a) && l.push(a),
                            a instanceof DocumentFragment)
                          )
                            for (a = a.firstChild; a; a = a.nextSibling)
                              i.push(a);
                          else i.push(a);
                        }
                        for (
                          c = s(this), X.apply(this, o), o = 0;
                          o < l.length;
                          o++
                        )
                          v(e, l[o]);
                        if (c)
                          for (v(e, this), o = 0; o < i.length; o++)
                            (l = i[o]) instanceof Element && w(e, l);
                      }),
                    void 0 !== q &&
                      d(n, 'remove', function () {
                        var r = s(this);
                        q.call(this), r && v(e, this);
                      });
                })(r);
            })(),
            (document.__CE_hasRegistry = !0);
          var _t = new y(b);
          Object.defineProperty(window, 'customElements', {
            configurable: !0,
            enumerable: !0,
            value: _t,
          });
        }
      }).call(self),
        'string' != typeof document.baseURI &&
          Object.defineProperty(Document.prototype, 'baseURI', {
            enumerable: !0,
            configurable: !0,
            get: function () {
              var f = document.querySelector('base');
              return f && f.href ? f.href : document.URL;
            },
          }),
        'function' != typeof window.CustomEvent &&
          ((window.CustomEvent = function (f, h) {
            h = h || { bubbles: !1, cancelable: !1, detail: void 0 };
            var s = document.createEvent('CustomEvent');
            return s.initCustomEvent(f, h.bubbles, h.cancelable, h.detail), s;
          }),
          (window.CustomEvent.prototype = window.Event.prototype)),
        (f = Event.prototype),
        (h = document),
        (s = window),
        f.composedPath ||
          (f.composedPath = function () {
            if (this.path) return this.path;
            var m = this.target;
            for (this.path = []; null !== m.parentNode; )
              this.path.push(m), (m = m.parentNode);
            return this.path.push(h, s), this.path;
          }),
        (function (f) {
          'function' != typeof f.matches &&
            (f.matches =
              f.msMatchesSelector ||
              f.mozMatchesSelector ||
              f.webkitMatchesSelector ||
              function (h) {
                h = (this.document || this.ownerDocument).querySelectorAll(h);
                for (var s = 0; h[s] && h[s] !== this; ) ++s;
                return !!h[s];
              }),
            'function' != typeof f.closest &&
              (f.closest = function (h) {
                for (var s = this; s && 1 === s.nodeType; ) {
                  if (s.matches(h)) return s;
                  s = s.parentNode;
                }
                return null;
              });
        })(window.Element.prototype),
        (function (f) {
          function h(m) {
            return (m = s(m)) && 11 === m.nodeType ? h(m.host) : m;
          }
          function s(m) {
            return m && m.parentNode ? s(m.parentNode) : m;
          }
          'function' != typeof f.getRootNode &&
            (f.getRootNode = function (m) {
              return m && m.composed ? h(this) : s(this);
            });
        })(Element.prototype),
        (function (f) {
          'isConnected' in f ||
            Object.defineProperty(f, 'isConnected', {
              configurable: !0,
              enumerable: !0,
              get: function () {
                var h = this.getRootNode({ composed: !0 });
                return h && 9 === h.nodeType;
              },
            });
        })(Element.prototype),
        [
          Element.prototype,
          CharacterData.prototype,
          DocumentType.prototype,
        ].forEach(function (h) {
          h.hasOwnProperty('remove') ||
            Object.defineProperty(h, 'remove', {
              configurable: !0,
              enumerable: !0,
              writable: !0,
              value: function () {
                null !== this.parentNode && this.parentNode.removeChild(this);
              },
            });
        }),
        (function (f) {
          'classList' in f ||
            Object.defineProperty(f, 'classList', {
              get: function () {
                var h = this,
                  s = (h.getAttribute('class') || '')
                    .replace(/^\s+|\s$/g, '')
                    .split(/\s+/g);
                function m() {
                  s.length > 0
                    ? h.setAttribute('class', s.join(' '))
                    : h.removeAttribute('class');
                }
                return (
                  '' === s[0] && s.splice(0, 1),
                  (s.toggle = function (p, d) {
                    void 0 !== d
                      ? d
                        ? s.add(p)
                        : s.remove(p)
                      : -1 !== s.indexOf(p)
                        ? s.splice(s.indexOf(p), 1)
                        : s.push(p),
                      m();
                  }),
                  (s.add = function () {
                    for (
                      var p = [].slice.call(arguments), d = 0, C = p.length;
                      d < C;
                      d++
                    )
                      -1 === s.indexOf(p[d]) && s.push(p[d]);
                    m();
                  }),
                  (s.remove = function () {
                    for (
                      var p = [].slice.call(arguments), d = 0, C = p.length;
                      d < C;
                      d++
                    )
                      -1 !== s.indexOf(p[d]) && s.splice(s.indexOf(p[d]), 1);
                    m();
                  }),
                  (s.item = function (p) {
                    return s[p];
                  }),
                  (s.contains = function (p) {
                    return -1 !== s.indexOf(p);
                  }),
                  (s.replace = function (p, d) {
                    -1 !== s.indexOf(p) && s.splice(s.indexOf(p), 1, d), m();
                  }),
                  (s.value = h.getAttribute('class') || ''),
                  s
                );
              },
            });
        })(Element.prototype),
        (function (f) {
          try {
            document.body.classList.add();
          } catch {
            var h = f.add,
              s = f.remove;
            (f.add = function () {
              for (var p = 0; p < arguments.length; p++)
                h.call(this, arguments[p]);
            }),
              (f.remove = function () {
                for (var p = 0; p < arguments.length; p++)
                  s.call(this, arguments[p]);
              });
          }
        })(DOMTokenList.prototype);
    },
  },
]);
