'use strict';
(self.webpackChunkapp = self.webpackChunkapp || []).push([
  [1577],
  {
    1577: (r, c, s) => {
      s.r(c), s.d(c, { ion_text: () => a });
      var t = s(4261),
        n = s(333),
        l = s(9483);
      const a = (() => {
        let e = class {
          constructor(o) {
            (0, t.r)(this, o), (this.color = void 0);
          }
          render() {
            const o = (0, l.b)(this);
            return (0, t.h)(
              t.f,
              {
                key: '4b76333b1ea5cab134b9dc1f5670c0d5a253fc32',
                class: (0, n.c)(this.color, { [o]: !0 }),
              },
              (0, t.h)('slot', {
                key: '3dee5f16bc58b3d92547d910bd4f441a00ce2039',
              }),
            );
          }
        };
        return (e.style = ':host(.ion-color){color:var(--ion-color-base)}'), e;
      })();
    },
  },
]);
