'use strict';
(self.webpackChunkapp = self.webpackChunkapp || []).push([
  [7240],
  {
    7240: (e, s, t) => {
      t.r(s), t.d(s, { ion_backdrop: () => p });
      var a = t(4261),
        n = t(9483);
      const p = (() => {
        let r = class {
          constructor(o) {
            (0, a.r)(this, o),
              (this.ionBackdropTap = (0, a.d)(this, 'ionBackdropTap', 7)),
              (this.visible = !0),
              (this.tappable = !0),
              (this.stopPropagation = !0);
          }
          onMouseDown(o) {
            this.emitTap(o);
          }
          emitTap(o) {
            this.stopPropagation && (o.preventDefault(), o.stopPropagation()),
              this.tappable && this.ionBackdropTap.emit();
          }
          render() {
            const o = (0, n.b)(this);
            return (0, a.h)(a.f, {
              key: 'c803b4302c8e722064feb03dafe3cb6e190b4f2b',
              tabindex: '-1',
              'aria-hidden': 'true',
              class: {
                [o]: !0,
                'backdrop-hide': !this.visible,
                'backdrop-no-tappable': !this.tappable,
              },
            });
          }
        };
        return (
          (r.style = {
            ios: ':host{left:0;right:0;top:0;bottom:0;display:block;position:absolute;-webkit-transform:translateZ(0);transform:translateZ(0);contain:strict;cursor:pointer;opacity:0.01;-ms-touch-action:none;touch-action:none;z-index:2}:host(.backdrop-hide){background:transparent}:host(.backdrop-no-tappable){cursor:auto}:host{background-color:var(--ion-backdrop-color, #000)}',
            md: ':host{left:0;right:0;top:0;bottom:0;display:block;position:absolute;-webkit-transform:translateZ(0);transform:translateZ(0);contain:strict;cursor:pointer;opacity:0.01;-ms-touch-action:none;touch-action:none;z-index:2}:host(.backdrop-hide){background:transparent}:host(.backdrop-no-tappable){cursor:auto}:host{background-color:var(--ion-backdrop-color, #000)}',
          }),
          r
        );
      })();
    },
  },
]);
